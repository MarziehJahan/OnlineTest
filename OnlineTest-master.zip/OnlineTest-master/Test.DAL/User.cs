﻿namespace Test.DAL
{
    public class User
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
    }
}