﻿namespace Test.DAL
{
    public class Question
    {
        public int QuestionId { get; set; }
        public string QuestionText { get; set; }
    }
}
